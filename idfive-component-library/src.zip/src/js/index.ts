/**
 * Styles
 */
import "../scss/index.scss";

/**
 * Modules
 */
import { silcCoreInit } from "silc-core";
import { silcAccordionInit } from "silc-accordion";
import { silcNavInit } from "silc-nav";
import { silcOffcanvasInit } from "silc-offcanvas";
import { searchToggle } from "../components/utility-menu/utility-menu";
import  sidebarNav  from "../components/sidebar-nav/sidebar-nav";

/**
 *
 * Init
 */
silcCoreInit();
silcAccordionInit();
silcNavInit();
silcOffcanvasInit();

searchToggle();

function sidebarNavInit() {
    [].forEach.call(document.querySelectorAll('.sidebar-nav .silc-nav__item--parent'), (el) => {
        new sidebarNav(el);
    });
}


sidebarNavInit();
window.addEventListener("load", function() {
  let navToggle = document.querySelector(".main-header__trigger-menu");
  let mainHeader = document.querySelector(".main-header");
  let navClose = document.querySelectorAll(".main-nav__ul a");
  let sidebarClose =document.querySelectorAll('.silc-offcanvas__trigger')
  if (navToggle) {
    for (let i = 0; i < navClose.length; i++) {
      navClose[i].addEventListener("click", function(event) {
        if (mainHeader.classList.contains("nav-toggled")) {
          mainHeader.classList.remove("nav-toggled");
        }
      });
    }

    navToggle.addEventListener("click", function() {
      if (!mainHeader.classList.contains("nav-toggled")) {
        mainHeader.classList.add("nav-toggled");
      } else {
        mainHeader.classList.remove("nav-toggled");
      }
    });

    navToggle.addEventListener("click", function() {
      if (!mainHeader.classList.contains("nav-toggled")) {
        mainHeader.classList.add("nav-toggled");
      } else {
        mainHeader.classList.remove("nav-toggled");
      }
    });

    window.addEventListener("resize", function() {
      if (mainHeader.classList.contains("nav-toggled")) {
        mainHeader.classList.remove("nav-toggled");
      }
    });
  }
  if(sidebarClose){ for (let i = 0; i < sidebarClose.length; i++) {
    sidebarClose[i].addEventListener("click", function(event) {

      sidebarClose[i].classList.toggle("sidebar-open");

    });
  }}
});



