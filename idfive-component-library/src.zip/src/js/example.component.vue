<template>
  <div class="example-component">
    <p>This is an example component</p>
  </div>
</template>

<script lang="ts">
export default {
  data: function() {
    return {
      foo: 'bar'
    }
  }
};
</script>

<style lang="scss">
.example-component {
  font-size: inherit;
}
</style>
