## Behavior options

### Open first accordion by default
Add data attribute `data-silc-accordion-open-first`

### Open multiple sections simultaneously
Add data attribute `data-silc-accordion-open-multiple`

## Uniqueness
Tabs and accordions that become tabs must have a unique id addeded to each section, that is then referenced within the navigation link.
